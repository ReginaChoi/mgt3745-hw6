import { useState, useRef, useCallback } from "react";
import { ShieldCheck, AlertCircle, Loader2, CheckCircle2 } from "lucide-react";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

type FormState = {
  candidate_name: string;
  degree_discipline: string;
  graduation_year: string;
  work_authorization: string;
  coursework_artifact_url: string;
};

const EMPTY_FORM: FormState = {
  candidate_name: "",
  degree_discipline: "",
  graduation_year: "",
  work_authorization: "",
  coursework_artifact_url: "",
};

const FIELD_LABELS: Record<keyof FormState, string> = {
  candidate_name: "Candidate Name",
  degree_discipline: "Accredited Degree Discipline",
  graduation_year: "Graduation Year",
  work_authorization: "Work Authorization Status",
  coursework_artifact_url: "Coursework Artifact URL",
};

const REQUIRED_FIELDS = Object.keys(EMPTY_FORM) as (keyof FormState)[];

const WORK_AUTH_OPTIONS = [
  "Citizen",
  "Permanent Resident",
  "H-1B Visa",
  "F-1 OPT",
  "Green Card Holder",
  "Other",
];

function validateClient(form: FormState): string | null {
  for (const field of REQUIRED_FIELDS) {
    const value = form[field].trim();
    if (value === "") {
      return `Missing required field: ${FIELD_LABELS[field]}`;
    }
  }
  if (form.graduation_year.trim() !== "") {
    const year = Number(form.graduation_year);
    if (!Number.isFinite(year) || !Number.isInteger(year) || year < 1900 || year > 2100) {
      return `Invalid value: ${FIELD_LABELS.graduation_year} must be a valid year (1900–2100)`;
    }
  }
  if (form.coursework_artifact_url.trim() !== "") {
    try {
      new URL(form.coursework_artifact_url.trim());
    } catch {
      return `Invalid value: ${FIELD_LABELS.coursework_artifact_url} must be a valid URL`;
    }
  }
  return null;
}

function App() {
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [statusMessage, setStatusMessage] = useState<string>("");
  const [statusType, setStatusType] = useState<"idle" | "error" | "success">("idle");
  const [submitting, setSubmitting] = useState(false);
  const statusRef = useRef<HTMLDivElement>(null);

  const handleChange = useCallback(
    (field: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setForm((prev) => ({ ...prev, [field]: e.target.value }));
      if (statusType === "success") {
        setStatusType("idle");
        setStatusMessage("");
      }
    },
    [statusType],
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Client-side gate: halt network submission if any required field is empty
    const clientError = validateClient(form);
    if (clientError) {
      setStatusType("error");
      setStatusMessage(clientError);
      if (statusRef.current) {
        statusRef.current.textContent = clientError;
      }
      return;
    }

    setSubmitting(true);
    setStatusType("idle");
    setStatusMessage("");
    if (statusRef.current) {
      statusRef.current.textContent = "";
    }

    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/verify-candidate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          candidate_name: form.candidate_name.trim(),
          degree_discipline: form.degree_discipline.trim(),
          graduation_year: Number(form.graduation_year),
          work_authorization: form.work_authorization.trim(),
          coursework_artifact_url: form.coursework_artifact_url.trim(),
        }),
      });

      if (!response.ok) {
        let serverError = "Submission failed";
        try {
          const errorBody = await response.json();
          if (errorBody?.error) {
            serverError = errorBody.error;
          }
        } catch {
          // response body wasn't JSON — keep default message
        }
        setStatusType("error");
        setStatusMessage(serverError);
        if (statusRef.current) {
          statusRef.current.textContent = serverError;
        }
        return;
      }

      const data = await response.json();
      setStatusType("success");
      const successMsg = data?.record
        ? `Verification record stored for ${data.record.candidate_name}.`
        : "Verification record stored successfully.";
      setStatusMessage(successMsg);
      if (statusRef.current) {
        statusRef.current.textContent = successMsg;
      }
      setForm(EMPTY_FORM);
    } catch {
      const networkError = "Network error: unable to reach the verification server.";
      setStatusType("error");
      setStatusMessage(networkError);
      if (statusRef.current) {
        statusRef.current.textContent = networkError;
      }
    } finally {
      setSubmitting(false);
    }
  };

  const inputBaseClass =
    "w-full rounded-md border px-3 py-2 text-sm transition-colors focus:outline-none focus:ring-2";
  const normalBorder = "border-gray-300";
  const focusRing = "focus:ring-[var(--color-focus)] focus:border-[var(--color-focus)]";

  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-6 bg-[var(--color-background)]">
      <div className="w-full max-w-2xl">
        <div className="mb-6 text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[var(--color-primary)] mb-3">
            <ShieldCheck className="w-7 h-7 text-white" strokeWidth={2} />
          </div>
          <h1 className="text-2xl font-bold text-[var(--color-primary)] tracking-tight">
            Candidate Verification
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Strict schema validation on client and edge server before persistence.
          </p>
        </div>

        <div
          className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sm:p-8"
          style={{ borderRadius: "var(--radius)" }}
        >
          <form onSubmit={handleSubmit} className="space-y-5" noValidate>
            {/* Candidate Name */}
            <div>
              <label
                htmlFor="candidate_name"
                className="block text-sm font-semibold mb-1.5"
                style={{ color: "var(--color-text)" }}
              >
                Candidate Name <span style={{ color: "var(--color-error)" }}>*</span>
              </label>
              <input
                id="candidate_name"
                type="text"
                value={form.candidate_name}
                onChange={handleChange("candidate_name")}
                placeholder="e.g. Jane Doe"
                className={`${inputBaseClass} ${normalBorder} ${focusRing}`}
                autoComplete="off"
              />
            </div>

            {/* Degree Discipline */}
            <div>
              <label
                htmlFor="degree_discipline"
                className="block text-sm font-semibold mb-1.5"
                style={{ color: "var(--color-text)" }}
              >
                Accredited Degree Discipline <span style={{ color: "var(--color-error)" }}>*</span>
              </label>
              <input
                id="degree_discipline"
                type="text"
                value={form.degree_discipline}
                onChange={handleChange("degree_discipline")}
                placeholder="e.g. Computer Science"
                className={`${inputBaseClass} ${normalBorder} ${focusRing}`}
                autoComplete="off"
              />
            </div>

            {/* Graduation Year */}
            <div>
              <label
                htmlFor="graduation_year"
                className="block text-sm font-semibold mb-1.5"
                style={{ color: "var(--color-text)" }}
              >
                Graduation Year <span style={{ color: "var(--color-error)" }}>*</span>
              </label>
              <input
                id="graduation_year"
                type="number"
                value={form.graduation_year}
                onChange={handleChange("graduation_year")}
                placeholder="e.g. 2024"
                min={1900}
                max={2100}
                className={`${inputBaseClass} ${normalBorder} ${focusRing}`}
                autoComplete="off"
              />
            </div>

            {/* Work Authorization */}
            <div>
              <label
                htmlFor="work_authorization"
                className="block text-sm font-semibold mb-1.5"
                style={{ color: "var(--color-text)" }}
              >
                Work Authorization Status <span style={{ color: "var(--color-error)" }}>*</span>
              </label>
              <select
                id="work_authorization"
                value={form.work_authorization}
                onChange={handleChange("work_authorization")}
                className={`${inputBaseClass} ${normalBorder} ${focusRing} bg-white`}
              >
                <option value="">Select an option…</option>
                {WORK_AUTH_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            {/* Coursework Artifact URL */}
            <div>
              <label
                htmlFor="coursework_artifact_url"
                className="block text-sm font-semibold mb-1.5"
                style={{ color: "var(--color-text)" }}
              >
                Coursework Artifact URL <span style={{ color: "var(--color-error)" }}>*</span>
              </label>
              <input
                id="coursework_artifact_url"
                type="url"
                value={form.coursework_artifact_url}
                onChange={handleChange("coursework_artifact_url")}
                placeholder="https://…"
                className={`${inputBaseClass} ${normalBorder} ${focusRing}`}
                autoComplete="off"
              />
            </div>

            {/* Status element — uses textContent, never innerHTML */}
            <div
              ref={statusRef}
              role="status"
              aria-live="polite"
              className={`min-h-[2.5rem] flex items-start gap-2 rounded-md px-4 py-2.5 text-sm transition-opacity ${
                statusType === "idle" ? "opacity-0 h-0 min-h-0 py-0 overflow-hidden" : "opacity-100"
              } ${
                statusType === "error"
                  ? "bg-red-50 text-[var(--color-error)] border border-[var(--color-error)]"
                  : statusType === "success"
                    ? "bg-green-50 text-green-800 border border-green-300"
                    : ""
              }`}
            >
              {statusType === "error" && (
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" strokeWidth={2} />
              )}
              {statusType === "success" && (
                <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" strokeWidth={2} />
              )}
              <span>{statusMessage}</span>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full flex items-center justify-center gap-2 rounded-md py-2.5 text-sm font-semibold text-white transition-colors disabled:opacity-60 disabled:cursor-not-allowed hover:opacity-90"
              style={{
                backgroundColor: "var(--color-primary)",
                borderRadius: "var(--radius)",
              }}
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" strokeWidth={2} />
                  Submitting…
                </>
              ) : (
                "Submit Verification"
              )}
            </button>
          </form>
        </div>

        <p className="text-xs text-gray-400 text-center mt-4">
          Only the five specified fields are accepted. Extra or empty fields are rejected with HTTP
          400.
        </p>
      </div>
    </div>
  );
}

export default App;
