import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const REQUIRED_FIELDS = [
  "candidate_name",
  "degree_discipline",
  "graduation_year",
  "work_authorization",
  "coursework_artifact_url",
] as const;

type VerificationPayload = {
  candidate_name: unknown;
  degree_discipline: unknown;
  graduation_year: unknown;
  work_authorization: unknown;
  coursework_artifact_url: unknown;
};

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function isValidPayload(obj: Record<string, unknown>): obj is VerificationPayload {
  for (const field of REQUIRED_FIELDS) {
    const value = obj[field];
    if (value === null || value === undefined) return false;
    if (field === "graduation_year") {
      if (typeof value !== "number" || !Number.isFinite(value)) return false;
    } else {
      if (!isNonEmptyString(value)) return false;
    }
  }
  return true;
}

function hasExtraFields(obj: Record<string, unknown>): boolean {
  const allowed = new Set<string>(REQUIRED_FIELDS);
  return Object.keys(obj).some((key) => !allowed.has(key));
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return new Response(
        JSON.stringify({ error: "Method not allowed" }),
        { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    let body: Record<string, unknown>;
    try {
      body = await req.json();
    } catch {
      return new Response(
        JSON.stringify({ error: "Missing required verification fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    if (typeof body !== "object" || body === null || Array.isArray(body)) {
      return new Response(
        JSON.stringify({ error: "Missing required verification fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Reject payloads with attributes outside the allowed schema
    if (hasExtraFields(body)) {
      return new Response(
        JSON.stringify({ error: "Missing required verification fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Validate all required fields are present and non-empty
    if (!isValidPayload(body)) {
      return new Response(
        JSON.stringify({ error: "Missing required verification fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    const { data, error } = await supabase
      .from("candidate_verifications")
      .insert({
        candidate_name: body.candidate_name,
        degree_discipline: body.degree_discipline,
        graduation_year: body.graduation_year,
        work_authorization: body.work_authorization,
        coursework_artifact_url: body.coursework_artifact_url,
      })
      .select()
      .single();

    if (error) {
      return new Response(
        JSON.stringify({ error: "Failed to persist verification record" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ success: true, record: data }),
      { status: 201, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
