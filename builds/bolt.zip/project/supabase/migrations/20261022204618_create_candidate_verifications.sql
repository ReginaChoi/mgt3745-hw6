/*
# Create candidate_verifications table (single-tenant, no auth)

1. New Tables
- `candidate_verifications` — stores candidate verification records submitted through
  the intake form. Each row represents one candidate's verification entry.
  - `id` (uuid, primary key, auto-generated)
  - `candidate_name` (text, not null) — full name of the candidate
  - `degree_discipline` (text, not null) — accredited degree discipline
  - `graduation_year` (int, not null) — year of graduation
  - `work_authorization` (text, not null) — work authorization status
  - `coursework_artifact_url` (text, not null) — URL to coursework artifact
  - `created_at` (timestamptz, default now()) — audit timestamp

2. Security
- Enable RLS on `candidate_verifications`.
- Grant CRUD to `anon` + `authenticated` so the Data API can reach the table
  (no-auth single-tenant app; data is intentionally shared).
- Allow anon + authenticated CRUD via permissive policies because the
  app has no sign-in screen and data is intentionally public/shared.
*/

CREATE TABLE IF NOT EXISTS candidate_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_name text NOT NULL,
  degree_discipline text NOT NULL,
  graduation_year integer NOT NULL,
  work_authorization text NOT NULL,
  coursework_artifact_url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE candidate_verifications ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON candidate_verifications TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_cv" ON candidate_verifications;
CREATE POLICY "anon_select_cv" ON candidate_verifications FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_cv" ON candidate_verifications;
CREATE POLICY "anon_insert_cv" ON candidate_verifications FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_cv" ON candidate_verifications;
CREATE POLICY "anon_update_cv" ON candidate_verifications FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_cv" ON candidate_verifications;
CREATE POLICY "anon_delete_cv" ON candidate_verifications FOR DELETE
  TO anon, authenticated USING (true);
