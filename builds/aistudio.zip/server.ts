import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Persistent database storage directories
const DATA_DIR = path.resolve(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const RECORDS_FILE = path.join(DATA_DIR, 'verifications.json');
const AUDIT_FILE = path.join(DATA_DIR, 'audit_log.json');

// Helper to read/write persistent data
interface VerificationRecord {
  id: string;
  candidateName: string;
  degreeDiscipline: string;
  graduationYear: number;
  workAuthorizationStatus: string;
  courseworkArtifactUrl: string;
  timestamp: string;
  status: 'COMMITTED';
  recordHash: string;
}

interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: 'VERIFICATION_COMMITTED' | 'EDGE_REJECTED_400' | 'CLIENT_VALIDATION_HALTED' | 'EDGE_SCHEMA_VIOLATION';
  httpStatus: number | 'CLIENT_HALTED';
  payloadSummary: Record<string, unknown>;
  outcome: 'SUCCESS' | 'REJECTED' | 'HALTED';
  reason: string;
  missingFields?: string[];
  disallowedFields?: string[];
}

function loadRecords(): VerificationRecord[] {
  try {
    if (fs.existsSync(RECORDS_FILE)) {
      const data = fs.readFileSync(RECORDS_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading records file:', err);
  }
  // Initial seed record if empty
  const initialSeed: VerificationRecord[] = [
    {
      id: 'VER-2026-9041',
      candidateName: 'Alexandra Chen',
      degreeDiscipline: 'Quantitative Finance & Economics',
      graduationYear: 2024,
      workAuthorizationStatus: 'US Citizen',
      courseworkArtifactUrl: 'https://credentials.audited.edu/artifacts/achen-thesis-2024.pdf',
      timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
      status: 'COMMITTED',
      recordHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    }
  ];
  fs.writeFileSync(RECORDS_FILE, JSON.stringify(initialSeed, null, 2));
  return initialSeed;
}

function saveRecords(records: VerificationRecord[]) {
  try {
    fs.writeFileSync(RECORDS_FILE, JSON.stringify(records, null, 2));
  } catch (err) {
    console.error('Error saving records:', err);
  }
}

function loadAudit(): AuditLogEntry[] {
  try {
    if (fs.existsSync(AUDIT_FILE)) {
      const data = fs.readFileSync(AUDIT_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading audit file:', err);
  }
  const initialAudit: AuditLogEntry[] = [
    {
      id: 'AUD-INIT-001',
      timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
      action: 'VERIFICATION_COMMITTED',
      httpStatus: 200,
      payloadSummary: { candidateName: 'Alexandra Chen', graduationYear: 2024 },
      outcome: 'SUCCESS',
      reason: 'Schema verification passed. Record committed to immutable store.'
    }
  ];
  fs.writeFileSync(AUDIT_FILE, JSON.stringify(initialAudit, null, 2));
  return initialAudit;
}

function appendAudit(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>): AuditLogEntry {
  const audit = loadAudit();
  const fullEntry: AuditLogEntry = {
    ...entry,
    id: `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: new Date().toISOString()
  };
  audit.unshift(fullEntry);
  try {
    fs.writeFileSync(AUDIT_FILE, JSON.stringify(audit, null, 2));
  } catch (err) {
    console.error('Error writing audit log:', err);
  }
  return fullEntry;
}

const ALLOWED_SCHEMA_FIELDS = new Set([
  'candidateName',
  'degreeDiscipline',
  'graduationYear',
  'workAuthorizationStatus',
  'courseworkArtifactUrl'
]);

// 1. Strict Schema Verification & Error Gate Endpoint
app.post('/api/verify', (req: Request, res: Response) => {
  const payload = req.body;

  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    appendAudit({
      action: 'EDGE_REJECTED_400',
      httpStatus: 400,
      payloadSummary: { rawType: typeof payload },
      outcome: 'REJECTED',
      reason: 'Payload is null or not a JSON object'
    });
    return res.status(400).json({ error: 'Missing required verification fields' });
  }

  // 1. Check for extra/disallowed attributes (Ubiquitous: restricting payload attributes strictly to the 5 fields)
  const incomingKeys = Object.keys(payload);
  const extraKeys = incomingKeys.filter(k => !ALLOWED_SCHEMA_FIELDS.has(k));
  if (extraKeys.length > 0) {
    appendAudit({
      action: 'EDGE_SCHEMA_VIOLATION',
      httpStatus: 400,
      payloadSummary: payload,
      outcome: 'REJECTED',
      reason: `Unauthorized attributes rejected under strict schema: ${extraKeys.join(', ')}`,
      disallowedFields: extraKeys
    });
    return res.status(400).json({
      error: 'Strict schema violation: payload contains unauthorized attributes',
      disallowedFields: extraKeys,
      allowedAttributes: Array.from(ALLOWED_SCHEMA_FIELDS)
    });
  }

  // 2. Check for missing, null, or empty fields
  // Requirement: "When an intake payload contains missing, null, or empty fields, the edge Worker shall reject the request with HTTP 400 Bad Request and return a descriptive JSON error ({"error": "Missing required verification fields"})."
  const missingFields: string[] = [];
  for (const field of ALLOWED_SCHEMA_FIELDS) {
    const val = payload[field];
    if (val === undefined || val === null) {
      missingFields.push(field);
    } else if (typeof val === 'string' && val.trim() === '') {
      missingFields.push(field);
    }
  }

  if (missingFields.length > 0) {
    appendAudit({
      action: 'EDGE_REJECTED_400',
      httpStatus: 400,
      payloadSummary: payload,
      outcome: 'REJECTED',
      reason: `Missing required verification fields: ${missingFields.join(', ')}`,
      missingFields
    });
    // Requirement specifies: return a descriptive JSON error ({"error": "Missing required verification fields"})
    return res.status(400).json({
      error: 'Missing required verification fields',
      missingFields: missingFields,
      message: `The following required compliance fields are missing or empty: ${missingFields.join(', ')}`
    });
  }

  // 3. Strict format validations
  // Graduation Year: must be valid integer
  const gradYearNum = Number(payload.graduationYear);
  if (!Number.isInteger(gradYearNum) || gradYearNum < 1900 || gradYearNum > 2100) {
    appendAudit({
      action: 'EDGE_REJECTED_400',
      httpStatus: 400,
      payloadSummary: payload,
      outcome: 'REJECTED',
      reason: `Invalid graduation year format: ${payload.graduationYear}`
    });
    return res.status(400).json({
      error: 'Invalid graduation year. Must be a 4-digit integer between 1900 and 2100',
      field: 'graduationYear'
    });
  }

  // Coursework Artifact URL: must be valid URL
  try {
    const parsedUrl = new URL(payload.courseworkArtifactUrl);
    if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
      throw new Error('Must use HTTP or HTTPS protocol');
    }
  } catch {
    appendAudit({
      action: 'EDGE_REJECTED_400',
      httpStatus: 400,
      payloadSummary: payload,
      outcome: 'REJECTED',
      reason: `Invalid coursework artifact URL: ${payload.courseworkArtifactUrl}`
    });
    return res.status(400).json({
      error: 'Invalid coursework artifact URL. Must be a valid HTTP/HTTPS URL',
      field: 'courseworkArtifactUrl'
    });
  }

  // 4. Schema and field validations passed! Commit to persistent storage.
  const records = loadRecords();
  const recordId = `VER-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const recordContent = `${recordId}:${payload.candidateName}:${payload.degreeDiscipline}:${gradYearNum}:${payload.workAuthorizationStatus}:${payload.courseworkArtifactUrl}`;
  const recordHash = crypto.createHash('sha256').update(recordContent).digest('hex');

  const newRecord: VerificationRecord = {
    id: recordId,
    candidateName: payload.candidateName.trim(),
    degreeDiscipline: payload.degreeDiscipline.trim(),
    graduationYear: gradYearNum,
    workAuthorizationStatus: payload.workAuthorizationStatus.trim(),
    courseworkArtifactUrl: payload.courseworkArtifactUrl.trim(),
    timestamp: new Date().toISOString(),
    status: 'COMMITTED',
    recordHash
  };

  records.unshift(newRecord);
  saveRecords(records);

  appendAudit({
    action: 'VERIFICATION_COMMITTED',
    httpStatus: 200,
    payloadSummary: {
      id: newRecord.id,
      candidateName: newRecord.candidateName,
      degreeDiscipline: newRecord.degreeDiscipline,
      graduationYear: newRecord.graduationYear,
      recordHash: newRecord.recordHash
    },
    outcome: 'SUCCESS',
    reason: 'Record passed all schema validations and committed to persistent database.'
  });

  return res.status(200).json({
    status: 'COMMITTED',
    message: 'Candidate verification record successfully validated and committed.',
    record: newRecord
  });
});

// Client logging for pre-flight halts
app.post('/api/audit/client-halt', (req: Request, res: Response) => {
  const { missingFields, payload } = req.body;
  const entry = appendAudit({
    action: 'CLIENT_VALIDATION_HALTED',
    httpStatus: 'CLIENT_HALTED',
    payloadSummary: payload || {},
    outcome: 'HALTED',
    reason: `Network submission halted on client: missing required field(s) [${(missingFields || []).join(', ')}]`,
    missingFields: missingFields || []
  });
  return res.json({ status: 'ok', entry });
});

// Get all verified records
app.get('/api/records', (_req: Request, res: Response) => {
  res.json({ records: loadRecords() });
});

// Get immutable audit trail
app.get('/api/audit', (_req: Request, res: Response) => {
  res.json({ auditLogs: loadAudit() });
});

// Download complete project archive as ZIP
app.get('/api/download-zip', (_req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'verification-schema-f02.zip');
  try {
    const pyScript = `
import os, zipfile
EXCLUDE_DIRS = {'node_modules', 'dist', '.git', '.aistudio', '__pycache__'}
EXCLUDE_FILES = {'project.zip', 'verification-schema-f02.zip'}
zip_filename = 'verification-schema-f02.zip'
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith('.')]
        for file in files:
            if file in EXCLUDE_FILES or file.endswith('.zip'):
                continue
            filepath = os.path.join(root, file)
            arcname = os.path.relpath(filepath, '.')
            zipf.write(filepath, arcname)
`;
    execSync(`python3 -c "${pyScript.replace(/"/g, '\\"')}"`);
  } catch (err) {
    console.error('Note on dynamic zip creation:', err);
  }

  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="verification-schema-f02.zip"');
    res.download(zipPath, 'verification-schema-f02.zip');
  } else {
    res.status(500).json({ error: 'Zip file could not be generated' });
  }
});

// Vite middleware or production build serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const distDir = path.resolve(__dirname, 'dist');

  if (isProd && fs.existsSync(distDir)) {
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
