# Feature F-02: Strict Verification Schema & Error Gate

This project implements Feature F-02 (JOB-03) for financial document reviewers and compliance leads.

## Key Compliance Features

1. **Strict 5-Attribute Schema Enforcement**:
   - Only 5 attributes are permitted in intake records:
     - `candidateName` (string, required)
     - `degreeDiscipline` (string, required)
     - `graduationYear` (integer between 1900-2100, required)
     - `workAuthorizationStatus` (string, required)
     - `courseworkArtifactUrl` (valid HTTP/HTTPS URL, required)
   - Disallowed or unexpected attributes trigger immediate HTTP 400 Bad Request rejection.

2. **Edge Worker Error Gate**:
   - Rejects missing, null, or empty fields with HTTP 400 Bad Request and descriptive JSON:
     ```json
     {
       "error": "Missing required verification fields",
       "missingFields": ["..."]
     }
     ```

3. **Client-Side Pre-Flight Halt & Inline Warnings**:
   - Blocks network dispatch if any required field is empty.
   - Renders clear inline warning indicators underneath each missing input.
   - Retains all previously entered form data in form fields so users never lose entered inputs.

4. **DOM textContent Status Notification**:
   - Error and gate states are displayed in `#status-element` using `textContent` (without `innerHTML`).

5. **Persistent Storage & Immutable Audit Trail**:
   - Verified records are cryptographically fingerprinted (SHA-256) and committed to persistent storage in `data/verifications.json`.
   - Comprehensive audit logging in `data/audit_log.json` tracking all client halts, edge 400 rejections, and commits.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the fullstack development server (Port 3000)
npm run dev

# 3. Build for production
npm run build
```

Open `http://localhost:3000` in your browser.
