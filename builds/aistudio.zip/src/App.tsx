/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  Database, 
  FileText, 
  Send, 
  RotateCcw, 
  Terminal, 
  CheckCircle2, 
  XCircle, 
  Lock, 
  Search,
  ExternalLink,
  Download
} from 'lucide-react';
import { VerificationRecord, AuditLogEntry, ALLOWED_ATTRIBUTES } from './types.ts';

interface FormData {
  candidateName: string;
  degreeDiscipline: string;
  graduationYear: string;
  workAuthorizationStatus: string;
  courseworkArtifactUrl: string;
}

const INITIAL_FORM_DATA: FormData = {
  candidateName: '',
  degreeDiscipline: '',
  graduationYear: '',
  workAuthorizationStatus: '',
  courseworkArtifactUrl: '',
};

const ACCREDITED_DISCIPLINES = [
  'Computer Science & Engineering',
  'Quantitative Finance & Economics',
  'Accounting & Financial Auditing',
  'Data Science & Analytics',
  'Information Systems & Cyber Risk',
  'Applied Mathematics & Statistics',
];

const WORK_AUTH_OPTIONS = [
  'US Citizen',
  'Permanent Resident (Green Card)',
  'H-1B Specialty Occupation',
  'F-1 OPT STEM Extension',
  'TN NAFTA Professional',
  'Employment Authorized (Other)',
];

export default function App() {
  const [formData, setFormData] = useState<FormData>(INITIAL_FORM_DATA);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [isErrorActive, setIsErrorActive] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [networkHaltNotice, setNetworkHaltNotice] = useState<string | null>(null);

  // Inspector & Audit State
  const [records, setRecords] = useState<VerificationRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [activeTab, setActiveTab] = useState<'records' | 'audit' | 'inspector'>('records');
  const [lastHttpResponse, setLastHttpResponse] = useState<{
    status: number | string;
    statusText: string;
    payload: unknown;
    timestamp: string;
  } | null>(null);
  const [auditSearch, setAuditSearch] = useState<string>('');

  // Explicit status element ref to guarantee textContent usage as specified in F-02
  const statusElementRef = useRef<HTMLDivElement>(null);

  // Effect to update status element via textContent whenever error or success changes
  useEffect(() => {
    if (statusElementRef.current) {
      if (isErrorActive && errorMessage) {
        statusElementRef.current.textContent = errorMessage;
      } else if (successMessage) {
        statusElementRef.current.textContent = successMessage;
      } else {
        statusElementRef.current.textContent = 'Ready for record verification. Strict schema active.';
      }
    }
  }, [isErrorActive, errorMessage, successMessage]);

  // Fetch initial records and audit logs
  const fetchData = async () => {
    try {
      const [recRes, audRes] = await Promise.all([
        fetch('/api/records'),
        fetch('/api/audit'),
      ]);
      if (recRes.ok) {
        const data = await recRes.json();
        setRecords(data.records || []);
      }
      if (audRes.ok) {
        const data = await audRes.json();
        setAuditLogs(data.auditLogs || []);
      }
    } catch (err) {
      console.error('Error fetching data:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleInputChange = (field: keyof FormData, value: string) => {
    // Retain form data in state
    setFormData((prev) => ({ ...prev, [field]: value }));
    // Clear field-specific error if user types
    if (fieldErrors[field]) {
      setFieldErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  /**
   * Client-Side Verification Gate
   * Unwanted-behavior (IF): If a user attempts to submit the form with any required
   * compliance field empty, then the system shall halt network submission and display
   * an inline warning identifying the missing field.
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage('');
    setNetworkHaltNotice(null);

    const errors: Record<string, string> = {};

    if (!formData.candidateName || formData.candidateName.trim() === '') {
      errors.candidateName = 'Missing required field: Candidate name is mandatory.';
    }

    if (!formData.degreeDiscipline || formData.degreeDiscipline.trim() === '') {
      errors.degreeDiscipline = 'Missing required field: Accredited degree discipline is mandatory.';
    }

    if (!formData.graduationYear || formData.graduationYear.trim() === '') {
      errors.graduationYear = 'Missing required field: Graduation year is mandatory.';
    } else {
      const year = Number(formData.graduationYear);
      if (!Number.isInteger(year) || year < 1900 || year > 2100) {
        errors.graduationYear = 'Graduation year must be a 4-digit year (1900-2100).';
      }
    }

    if (!formData.workAuthorizationStatus || formData.workAuthorizationStatus.trim() === '') {
      errors.workAuthorizationStatus = 'Missing required field: Work authorization status is mandatory.';
    }

    if (!formData.courseworkArtifactUrl || formData.courseworkArtifactUrl.trim() === '') {
      errors.courseworkArtifactUrl = 'Missing required field: Coursework artifact URL is mandatory.';
    } else {
      try {
        const parsed = new URL(formData.courseworkArtifactUrl);
        if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
          errors.courseworkArtifactUrl = 'URL must begin with http:// or https://';
        }
      } catch {
        errors.courseworkArtifactUrl = 'Coursework artifact URL must be a valid URL.';
      }
    }

    // IF any required compliance field is empty, HALT network submission!
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      setIsErrorActive(true);
      const haltMsg = 'Network submission halted: Missing required compliance field(s). Correct inline warnings below.';
      setErrorMessage(haltMsg);
      setNetworkHaltNotice('Pre-submission check failed: Network request blocked at client gate. Data preserved in form.');

      // Record client-side halt in audit log on server
      fetch('/api/audit/client-halt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          missingFields: Object.keys(errors),
          payload: formData,
        }),
      }).then(() => fetchData()).catch(() => {});

      return; // HALT network submission!
    }

    // Client gate passed: send strictly restricted schema payload to edge worker
    setFieldErrors({});
    setIsErrorActive(false);
    setErrorMessage('');
    setIsSubmitting(true);

    const payload = {
      candidateName: formData.candidateName.trim(),
      degreeDiscipline: formData.degreeDiscipline.trim(),
      graduationYear: Number(formData.graduationYear),
      workAuthorizationStatus: formData.workAuthorizationStatus.trim(),
      courseworkArtifactUrl: formData.courseworkArtifactUrl.trim(),
    };

    try {
      const res = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const responseJson = await res.json();

      setLastHttpResponse({
        status: res.status,
        statusText: res.statusText,
        payload: responseJson,
        timestamp: new Date().toLocaleTimeString(),
      });

      if (!res.ok) {
        // Edge Worker rejected with HTTP 400 Bad Request
        // Requirement: State-driven: While an error state is active, the client UI shall
        // render the error message visibly in the status element using textContent and retain
        // previously entered data in form fields.
        setIsErrorActive(true);
        const errText = responseJson.error || 'Verification request failed at edge worker.';
        setErrorMessage(`HTTP ${res.status}: ${errText}`);
      } else {
        // Success: record committed
        setIsErrorActive(false);
        setErrorMessage('');
        setSuccessMessage(`Record ${responseJson.record?.id} committed to persistent audit log! Record Hash: ${responseJson.record?.recordHash.substring(0, 16)}...`);
        // We only clear form on successful intentional commit, while retaining on any error
        setFormData(INITIAL_FORM_DATA);
      }
    } catch (err: unknown) {
      setIsErrorActive(true);
      const msg = err instanceof Error ? err.message : 'Network failure reaching edge worker';
      setErrorMessage(`Edge Gate Error: ${msg}`);
    } finally {
      setIsSubmitting(false);
      fetchData();
    }
  };

  /**
   * Direct Edge Worker Test Suite:
   * Enables the Compliance Lead to test edge server schema rejections and HTTP 400 gate
   */
  const runDirectEdgeTest = async (testType: 'missing' | 'null' | 'disallowed' | 'valid') => {
    setIsSubmitting(true);
    setSuccessMessage('');
    setNetworkHaltNotice(null);

    let testPayload: Record<string, unknown> = {};

    if (testType === 'missing') {
      // Missing required verification fields
      testPayload = {
        candidateName: 'Test Incomplete Candidate',
        // degreeDiscipline is missing
        // graduationYear is missing
        workAuthorizationStatus: 'US Citizen',
        courseworkArtifactUrl: '', // empty
      };
    } else if (testType === 'null') {
      // Null required fields
      testPayload = {
        candidateName: null,
        degreeDiscipline: 'Quantitative Finance & Economics',
        graduationYear: null,
        workAuthorizationStatus: 'US Citizen',
        courseworkArtifactUrl: 'https://example.com/artifact.pdf',
      };
    } else if (testType === 'disallowed') {
      // Strict schema violation: unauthorized extra attribute
      testPayload = {
        candidateName: 'Compliance Test Subject',
        degreeDiscipline: 'Computer Science & Engineering',
        graduationYear: 2025,
        workAuthorizationStatus: 'US Citizen',
        courseworkArtifactUrl: 'https://example.com/project.pdf',
        unauthorizedAttribute: 'Malicious or extraneous data payload',
        internalReviewNotes: 'Should be rejected under strict schema',
      };
    } else if (testType === 'valid') {
      testPayload = {
        candidateName: 'Morgan J. Vance',
        degreeDiscipline: 'Quantitative Finance & Economics',
        graduationYear: 2023,
        workAuthorizationStatus: 'US Citizen',
        courseworkArtifactUrl: 'https://verified.edu/artifacts/morgan-vance-thesis.pdf',
      };
    }

    try {
      const res = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(testPayload),
      });

      const responseJson = await res.json();

      setLastHttpResponse({
        status: res.status,
        statusText: res.statusText,
        payload: responseJson,
        timestamp: new Date().toLocaleTimeString(),
      });

      if (!res.ok) {
        setIsErrorActive(true);
        // Requirement: edge Worker shall reject the request with HTTP 400 Bad Request and return descriptive JSON error ({"error": "Missing required verification fields"})
        const desc = responseJson.error || 'Missing required verification fields';
        setErrorMessage(`HTTP ${res.status} Bad Request: ${desc}`);
      } else {
        setIsErrorActive(false);
        setErrorMessage('');
        setSuccessMessage(`Direct test passed: Record ${responseJson.record?.id} committed.`);
      }
    } catch (err: unknown) {
      setIsErrorActive(true);
      const msg = err instanceof Error ? err.message : 'Edge Worker unreachable';
      setErrorMessage(`Edge Gate Communication Error: ${msg}`);
    } finally {
      setIsSubmitting(false);
      fetchData();
    }
  };

  const populateSampleData = () => {
    setFormData({
      candidateName: 'Julian C. Mercer',
      degreeDiscipline: 'Accounting & Financial Auditing',
      graduationYear: '2024',
      workAuthorizationStatus: 'US Citizen',
      courseworkArtifactUrl: 'https://credentials.mit.edu/artifacts/mercer-audit-practicum.pdf',
    });
    setFieldErrors({});
    setIsErrorActive(false);
    setErrorMessage('');
    setSuccessMessage('Loaded compliant candidate sample record. Ready to submit.');
    setNetworkHaltNotice(null);
  };

  const clearForm = () => {
    setFormData(INITIAL_FORM_DATA);
    setFieldErrors({});
    setIsErrorActive(false);
    setErrorMessage('');
    setSuccessMessage('');
    setNetworkHaltNotice(null);
  };

  const exportAuditTrailJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(auditLogs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `audit_trail_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const filteredAuditLogs = auditLogs.filter((log) => {
    if (!auditSearch.trim()) return true;
    const q = auditSearch.toLowerCase();
    return (
      log.action.toLowerCase().includes(q) ||
      log.reason.toLowerCase().includes(q) ||
      String(log.httpStatus).toLowerCase().includes(q) ||
      JSON.stringify(log.payloadSummary).toLowerCase().includes(q)
    );
  });

  return (
    <div 
      className="min-h-screen"
      style={{
        backgroundColor: 'var(--color-background)',
        color: 'var(--color-text)',
        fontFamily: 'var(--font-body)',
      }}
    >
      {/* Top Compliance Header */}
      <header 
        className="border-b"
        style={{
          backgroundColor: '#ffffff',
          borderColor: 'rgba(23, 43, 64, 0.15)',
          padding: 'calc(var(--space-unit) * 1.25) var(--space-unit)',
        }}
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div 
              className="p-2 flex items-center justify-center text-white"
              style={{
                backgroundColor: 'var(--color-primary)',
                borderRadius: 'var(--radius)',
              }}
            >
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight" style={{ color: 'var(--color-primary)' }}>
                  Verification Schema & Error Gate
                </h1>
                <span 
                  className="text-xs px-2 py-0.5 font-semibold uppercase tracking-wider text-white"
                  style={{
                    backgroundColor: 'var(--color-primary)',
                    borderRadius: 'var(--radius)',
                  }}
                >
                  Feature F-02 (JOB-03)
                </span>
              </div>
              <p className="text-xs" style={{ color: 'var(--color-text)', opacity: 0.8 }}>
                Internal control standard for Financial Document Reviewer & Compliance Lead. Strict intake validation & audit.
              </p>
            </div>
          </div>

          {/* Standards & Controls Badges */}
          <div className="flex items-center gap-2 flex-wrap">
            <div 
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs border"
              style={{
                backgroundColor: 'var(--color-background)',
                borderColor: 'rgba(23, 43, 64, 0.2)',
                borderRadius: 'var(--radius)',
              }}
            >
              <Lock className="w-3.5 h-3.5" style={{ color: 'var(--color-focus)' }} />
              <span className="font-medium">Strict 5-Attribute Schema</span>
            </div>
            <div 
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs border"
              style={{
                backgroundColor: 'var(--color-background)',
                borderColor: 'rgba(23, 43, 64, 0.2)',
                borderRadius: 'var(--radius)',
              }}
            >
              <Terminal className="w-3.5 h-3.5" style={{ color: 'var(--color-primary)' }} />
              <span className="font-medium">Edge 400 Bad Request Gate</span>
            </div>
            <a
              href="/api/download-zip"
              download="verification-schema-f02.zip"
              className="flex items-center gap-1.5 px-3 py-1 text-xs font-bold text-white transition-opacity hover:opacity-90 shadow-sm"
              style={{
                backgroundColor: 'var(--color-primary)',
                borderRadius: 'var(--radius)',
              }}
              title="Download entire project codebase as a ZIP archive"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Project ZIP</span>
            </a>
            <button
              onClick={exportAuditTrailJson}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium border transition-colors hover:bg-slate-100"
              style={{
                borderColor: 'rgba(23, 43, 64, 0.3)',
                color: 'var(--color-text)',
                borderRadius: 'var(--radius)',
              }}
              title="Download full immutable audit trail JSON"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Audit JSON</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto p-3 md:p-6">
        {/* Compliance Status Element (JOB-03 State-driven Requirement) */}
        {/* Requirement: While an error state is active, the client UI shall render the error message visibly in the status element using textContent and retain previously entered data in form fields. */}
        <div 
          className="mb-6 p-3 border transition-all"
          style={{
            backgroundColor: isErrorActive 
              ? '#ffffff' 
              : successMessage 
                ? '#ffffff' 
                : '#ffffff',
            borderColor: isErrorActive 
              ? 'var(--color-error)' 
              : successMessage 
                ? 'var(--color-primary)' 
                : 'rgba(23, 43, 64, 0.2)',
            borderRadius: 'var(--radius)',
            borderLeftWidth: '6px',
            borderLeftColor: isErrorActive 
              ? 'var(--color-error)' 
              : successMessage 
                ? 'var(--color-primary)' 
                : 'var(--color-focus)',
          }}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5 flex-1">
              {isErrorActive ? (
                <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-error)' }} />
              ) : successMessage ? (
                <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-primary)' }} />
              ) : (
                <Lock className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--color-focus)' }} />
              )}
              <div className="w-full">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider" style={{
                    color: isErrorActive ? 'var(--color-error)' : 'var(--color-primary)'
                  }}>
                    {isErrorActive ? 'Schema Gate Status: Error State Active' : successMessage ? 'Schema Gate Status: Verified & Committed' : 'Schema Gate Status: Armed & Active'}
                  </span>
                  <span className="text-[11px] px-1.5 py-0.2 border rounded" style={{
                    color: 'var(--color-text)',
                    borderColor: 'rgba(23, 43, 64, 0.2)'
                  }}>
                    DOM Target: #status-element
                  </span>
                </div>
                {/* The explicit status element rendered using textContent */}
                <div 
                  id="status-element"
                  data-testid="status-element"
                  ref={statusElementRef}
                  className="text-sm font-semibold mt-1 break-words"
                  style={{
                    color: isErrorActive ? 'var(--color-error)' : 'var(--color-text)'
                  }}
                >
                  {/* Initial text content fallback; sync effect also sets textContent directly */}
                  Ready for record verification. Strict schema active.
                </div>
                {networkHaltNotice && (
                  <div 
                    className="text-xs mt-1 font-mono font-medium"
                    style={{ color: 'var(--color-error)' }}
                  >
                    [HALT ENFORCED]: {networkHaltNotice}
                  </div>
                )}
              </div>
            </div>
            {isErrorActive && (
              <button
                onClick={() => {
                  setIsErrorActive(false);
                  setErrorMessage('');
                  setNetworkHaltNotice(null);
                }}
                className="text-xs px-2 py-1 border hover:opacity-80"
                style={{
                  borderRadius: 'var(--radius)',
                  borderColor: 'var(--color-error)',
                  color: 'var(--color-error)'
                }}
              >
                Acknowledge
              </button>
            )}
          </div>
        </div>

        {/* Two-Column Grid: Left: Intake Form, Right: Test Harness & Audit Log */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Column 1: Candidate Verification Intake Form */}
          <div className="lg:col-span-6 flex flex-col gap-4">
            <div 
              className="p-4 md:p-5 border"
              style={{
                backgroundColor: '#ffffff',
                borderColor: 'rgba(23, 43, 64, 0.15)',
                borderRadius: 'var(--radius)',
              }}
            >
              <div className="flex items-center justify-between pb-3 mb-4 border-b" style={{ borderColor: 'rgba(23, 43, 64, 0.1)' }}>
                <div>
                  <h2 className="text-base font-bold" style={{ color: 'var(--color-primary)' }}>
                    Candidate Verification Intake Record
                  </h2>
                  <p className="text-xs" style={{ color: 'var(--color-text)', opacity: 0.75 }}>
                    Strict 5-attribute verification envelope. Incomplete submissions are halted at client or rejected by Edge Worker.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={populateSampleData}
                  className="text-xs px-2.5 py-1 border font-medium hover:opacity-80"
                  style={{
                    borderRadius: 'var(--radius)',
                    borderColor: 'var(--color-primary)',
                    color: 'var(--color-primary)',
                  }}
                >
                  Load Compliant Sample
                </button>
              </div>

              <form onSubmit={handleSubmit} noValidate>
                {/* Field 1: Candidate Name */}
                <div className="mb-3.5">
                  <div className="flex items-center justify-between mb-1">
                    <label 
                      htmlFor="candidateName" 
                      className="text-xs font-bold uppercase tracking-wider flex items-center gap-1"
                      style={{ color: 'var(--color-text)' }}
                    >
                      1. Candidate Name <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <span className="text-[11px] font-mono" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                      attribute: candidateName
                    </span>
                  </div>
                  <input
                    id="candidateName"
                    data-testid="candidateName-input"
                    type="text"
                    value={formData.candidateName}
                    onChange={(e) => handleInputChange('candidateName', e.target.value)}
                    placeholder="e.g. Jane M. Doe"
                    className="w-full px-3 py-2 text-sm border transition-colors"
                    style={{
                      borderRadius: 'var(--radius)',
                      borderColor: fieldErrors.candidateName ? 'var(--color-error)' : 'rgba(23, 43, 64, 0.3)',
                      backgroundColor: fieldErrors.candidateName ? '#fffbfb' : '#ffffff',
                      color: 'var(--color-text)',
                    }}
                  />
                  {/* Inline Warning Identifying Missing Field */}
                  {fieldErrors.candidateName && (
                    <div 
                      id="candidateName-warning"
                      data-testid="candidateName-warning"
                      className="text-xs mt-1 flex items-center gap-1 font-semibold"
                      style={{ color: 'var(--color-error)' }}
                    >
                      <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>{fieldErrors.candidateName}</span>
                    </div>
                  )}
                </div>

                {/* Field 2: Accredited Degree Discipline */}
                <div className="mb-3.5">
                  <div className="flex items-center justify-between mb-1">
                    <label 
                      htmlFor="degreeDiscipline" 
                      className="text-xs font-bold uppercase tracking-wider flex items-center gap-1"
                      style={{ color: 'var(--color-text)' }}
                    >
                      2. Accredited Degree Discipline <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <span className="text-[11px] font-mono" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                      attribute: degreeDiscipline
                    </span>
                  </div>
                  <input
                    id="degreeDiscipline"
                    data-testid="degreeDiscipline-input"
                    type="text"
                    list="disciplines-list"
                    value={formData.degreeDiscipline}
                    onChange={(e) => handleInputChange('degreeDiscipline', e.target.value)}
                    placeholder="Select or enter accredited discipline"
                    className="w-full px-3 py-2 text-sm border transition-colors"
                    style={{
                      borderRadius: 'var(--radius)',
                      borderColor: fieldErrors.degreeDiscipline ? 'var(--color-error)' : 'rgba(23, 43, 64, 0.3)',
                      backgroundColor: fieldErrors.degreeDiscipline ? '#fffbfb' : '#ffffff',
                      color: 'var(--color-text)',
                    }}
                  />
                  <datalist id="disciplines-list">
                    {ACCREDITED_DISCIPLINES.map((d) => (
                      <option key={d} value={d} />
                    ))}
                  </datalist>
                  {/* Inline Warning */}
                  {fieldErrors.degreeDiscipline && (
                    <div 
                      id="degreeDiscipline-warning"
                      data-testid="degreeDiscipline-warning"
                      className="text-xs mt-1 flex items-center gap-1 font-semibold"
                      style={{ color: 'var(--color-error)' }}
                    >
                      <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>{fieldErrors.degreeDiscipline}</span>
                    </div>
                  )}
                </div>

                {/* Field 3: Graduation Year */}
                <div className="mb-3.5">
                  <div className="flex items-center justify-between mb-1">
                    <label 
                      htmlFor="graduationYear" 
                      className="text-xs font-bold uppercase tracking-wider flex items-center gap-1"
                      style={{ color: 'var(--color-text)' }}
                    >
                      3. Graduation Year <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <span className="text-[11px] font-mono" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                      attribute: graduationYear
                    </span>
                  </div>
                  <input
                    id="graduationYear"
                    data-testid="graduationYear-input"
                    type="number"
                    min="1900"
                    max="2100"
                    value={formData.graduationYear}
                    onChange={(e) => handleInputChange('graduationYear', e.target.value)}
                    placeholder="e.g. 2024"
                    className="w-full px-3 py-2 text-sm border transition-colors"
                    style={{
                      borderRadius: 'var(--radius)',
                      borderColor: fieldErrors.graduationYear ? 'var(--color-error)' : 'rgba(23, 43, 64, 0.3)',
                      backgroundColor: fieldErrors.graduationYear ? '#fffbfb' : '#ffffff',
                      color: 'var(--color-text)',
                    }}
                  />
                  {/* Inline Warning */}
                  {fieldErrors.graduationYear && (
                    <div 
                      id="graduationYear-warning"
                      data-testid="graduationYear-warning"
                      className="text-xs mt-1 flex items-center gap-1 font-semibold"
                      style={{ color: 'var(--color-error)' }}
                    >
                      <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>{fieldErrors.graduationYear}</span>
                    </div>
                  )}
                </div>

                {/* Field 4: Work Authorization Status */}
                <div className="mb-3.5">
                  <div className="flex items-center justify-between mb-1">
                    <label 
                      htmlFor="workAuthorizationStatus" 
                      className="text-xs font-bold uppercase tracking-wider flex items-center gap-1"
                      style={{ color: 'var(--color-text)' }}
                    >
                      4. Work Authorization Status <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <span className="text-[11px] font-mono" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                      attribute: workAuthorizationStatus
                    </span>
                  </div>
                  <select
                    id="workAuthorizationStatus"
                    data-testid="workAuthorizationStatus-input"
                    value={formData.workAuthorizationStatus}
                    onChange={(e) => handleInputChange('workAuthorizationStatus', e.target.value)}
                    className="w-full px-3 py-2 text-sm border transition-colors"
                    style={{
                      borderRadius: 'var(--radius)',
                      borderColor: fieldErrors.workAuthorizationStatus ? 'var(--color-error)' : 'rgba(23, 43, 64, 0.3)',
                      backgroundColor: fieldErrors.workAuthorizationStatus ? '#fffbfb' : '#ffffff',
                      color: 'var(--color-text)',
                    }}
                  >
                    <option value="">-- Select Work Authorization Status --</option>
                    {WORK_AUTH_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                  {/* Inline Warning */}
                  {fieldErrors.workAuthorizationStatus && (
                    <div 
                      id="workAuthorizationStatus-warning"
                      data-testid="workAuthorizationStatus-warning"
                      className="text-xs mt-1 flex items-center gap-1 font-semibold"
                      style={{ color: 'var(--color-error)' }}
                    >
                      <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>{fieldErrors.workAuthorizationStatus}</span>
                    </div>
                  )}
                </div>

                {/* Field 5: Coursework Artifact URL */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-1">
                    <label 
                      htmlFor="courseworkArtifactUrl" 
                      className="text-xs font-bold uppercase tracking-wider flex items-center gap-1"
                      style={{ color: 'var(--color-text)' }}
                    >
                      5. Coursework Artifact URL <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <span className="text-[11px] font-mono" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                      attribute: courseworkArtifactUrl
                    </span>
                  </div>
                  <input
                    id="courseworkArtifactUrl"
                    data-testid="courseworkArtifactUrl-input"
                    type="url"
                    value={formData.courseworkArtifactUrl}
                    onChange={(e) => handleInputChange('courseworkArtifactUrl', e.target.value)}
                    placeholder="https://repository.accredited.edu/artifacts/sample.pdf"
                    className="w-full px-3 py-2 text-sm border transition-colors"
                    style={{
                      borderRadius: 'var(--radius)',
                      borderColor: fieldErrors.courseworkArtifactUrl ? 'var(--color-error)' : 'rgba(23, 43, 64, 0.3)',
                      backgroundColor: fieldErrors.courseworkArtifactUrl ? '#fffbfb' : '#ffffff',
                      color: 'var(--color-text)',
                    }}
                  />
                  {/* Inline Warning */}
                  {fieldErrors.courseworkArtifactUrl && (
                    <div 
                      id="courseworkArtifactUrl-warning"
                      data-testid="courseworkArtifactUrl-warning"
                      className="text-xs mt-1 flex items-center gap-1 font-semibold"
                      style={{ color: 'var(--color-error)' }}
                    >
                      <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>{fieldErrors.courseworkArtifactUrl}</span>
                    </div>
                  )}
                </div>

                {/* Strict Schema Boundary Notice */}
                <div 
                  className="p-2.5 mb-4 text-xs border font-mono"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    borderColor: 'rgba(23, 43, 64, 0.15)',
                    borderRadius: 'var(--radius)',
                  }}
                >
                  <div className="flex items-center gap-1.5 font-bold mb-1" style={{ color: 'var(--color-primary)' }}>
                    <Lock className="w-3.5 h-3.5" />
                    <span>Ubiquitous Schema Constraint:</span>
                  </div>
                  <div className="text-[11px] leading-relaxed">
                    Payload strictly restricted to 5 attributes. Extra keys (e.g. salary, comments, flags) trigger immediate HTTP 400 rejection.
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-3">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 text-sm font-bold text-white transition-opacity hover:opacity-95 disabled:opacity-50"
                    style={{
                      backgroundColor: 'var(--color-primary)',
                      borderRadius: 'var(--radius)',
                    }}
                  >
                    <Send className="w-4 h-4" />
                    <span>{isSubmitting ? 'Evaluating Gate...' : 'Submit Verification Record'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={clearForm}
                    className="px-3 py-2 text-sm border font-medium hover:opacity-80 flex items-center gap-1.5"
                    style={{
                      borderRadius: 'var(--radius)',
                      borderColor: 'rgba(23, 43, 64, 0.3)',
                      color: 'var(--color-text)',
                    }}
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Clear</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Direct Edge Server Test Harness */}
            <div 
              className="p-4 border"
              style={{
                backgroundColor: '#ffffff',
                borderColor: 'rgba(23, 43, 64, 0.15)',
                borderRadius: 'var(--radius)',
              }}
            >
              <div className="flex items-center gap-2 mb-2 pb-2 border-b" style={{ borderColor: 'rgba(23, 43, 64, 0.1)' }}>
                <Terminal className="w-4 h-4" style={{ color: 'var(--color-primary)' }} />
                <h3 className="text-sm font-bold" style={{ color: 'var(--color-primary)' }}>
                  Edge Worker Error Gate Inspector (Direct Server Testing)
                </h3>
              </div>
              <p className="text-xs mb-3" style={{ color: 'var(--color-text)', opacity: 0.8 }}>
                Simulate raw network payloads directly to the edge worker endpoint (<code className="font-mono">POST /api/verify</code>) to inspect strict schema rejections & HTTP 400 responses:
              </p>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => runDirectEdgeTest('missing')}
                  disabled={isSubmitting}
                  className="p-2 border text-left font-medium transition-colors hover:bg-slate-50 flex flex-col justify-between"
                  style={{
                    borderRadius: 'var(--radius)',
                    borderColor: 'var(--color-error)',
                    color: 'var(--color-error)',
                  }}
                >
                  <span className="font-bold">Test Missing Fields</span>
                  <span className="text-[10px] opacity-75 mt-0.5">Expects HTTP 400: Missing required verification fields</span>
                </button>

                <button
                  type="button"
                  onClick={() => runDirectEdgeTest('null')}
                  disabled={isSubmitting}
                  className="p-2 border text-left font-medium transition-colors hover:bg-slate-50 flex flex-col justify-between"
                  style={{
                    borderRadius: 'var(--radius)',
                    borderColor: 'var(--color-error)',
                    color: 'var(--color-error)',
                  }}
                >
                  <span className="font-bold">Test Null Fields</span>
                  <span className="text-[10px] opacity-75 mt-0.5">Expects HTTP 400 Bad Request</span>
                </button>

                <button
                  type="button"
                  onClick={() => runDirectEdgeTest('disallowed')}
                  disabled={isSubmitting}
                  className="p-2 border text-left font-medium transition-colors hover:bg-slate-50 flex flex-col justify-between"
                  style={{
                    borderRadius: 'var(--radius)',
                    borderColor: 'var(--color-focus)',
                    color: 'var(--color-focus)',
                  }}
                >
                  <span className="font-bold">Test Extra Attributes</span>
                  <span className="text-[10px] opacity-75 mt-0.5">Expects HTTP 400: Strict schema violation</span>
                </button>

                <button
                  type="button"
                  onClick={() => runDirectEdgeTest('valid')}
                  disabled={isSubmitting}
                  className="p-2 border text-left font-medium transition-colors hover:bg-slate-50 flex flex-col justify-between"
                  style={{
                    borderRadius: 'var(--radius)',
                    borderColor: 'var(--color-primary)',
                    color: 'var(--color-primary)',
                  }}
                >
                  <span className="font-bold">Test Valid Record</span>
                  <span className="text-[10px] opacity-75 mt-0.5">Expects HTTP 200: Committed to persistent storage</span>
                </button>
              </div>

              {lastHttpResponse && (
                <div 
                  className="mt-3 p-2.5 border font-mono text-[11px]"
                  style={{
                    backgroundColor: 'var(--color-background)',
                    borderColor: lastHttpResponse.status === 200 ? 'var(--color-primary)' : 'var(--color-error)',
                    borderRadius: 'var(--radius)',
                  }}
                >
                  <div className="flex items-center justify-between font-bold mb-1">
                    <span style={{ color: lastHttpResponse.status === 200 ? 'var(--color-primary)' : 'var(--color-error)' }}>
                      HTTP Response: {lastHttpResponse.status} {lastHttpResponse.statusText}
                    </span>
                    <span className="text-[10px]" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                      {lastHttpResponse.timestamp}
                    </span>
                  </div>
                  <pre className="overflow-x-auto p-1.5 bg-white border rounded text-[11px] leading-tight">
                    {JSON.stringify(lastHttpResponse.payload, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          </div>

          {/* Column 2: Audit Trail & Persistent Storage Records */}
          <div className="lg:col-span-6 flex flex-col gap-4">
            {/* View Switcher Tabs */}
            <div 
              className="p-1 border flex items-center gap-1"
              style={{
                backgroundColor: '#ffffff',
                borderColor: 'rgba(23, 43, 64, 0.15)',
                borderRadius: 'var(--radius)',
              }}
            >
              <button
                type="button"
                onClick={() => setActiveTab('records')}
                className="flex-1 py-1.5 px-3 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                style={{
                  borderRadius: 'var(--radius)',
                  backgroundColor: activeTab === 'records' ? 'var(--color-primary)' : 'transparent',
                  color: activeTab === 'records' ? '#ffffff' : 'var(--color-text)',
                }}
              >
                <Database className="w-3.5 h-3.5" />
                <span>Committed Records ({records.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('audit')}
                className="flex-1 py-1.5 px-3 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                style={{
                  borderRadius: 'var(--radius)',
                  backgroundColor: activeTab === 'audit' ? 'var(--color-primary)' : 'transparent',
                  color: activeTab === 'audit' ? '#ffffff' : 'var(--color-text)',
                }}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Immutable Audit Trail ({auditLogs.length})</span>
              </button>
            </div>

            {/* Tab 1: Committed Records Table */}
            {activeTab === 'records' && (
              <div 
                className="p-4 border flex flex-col gap-3"
                style={{
                  backgroundColor: '#ffffff',
                  borderColor: 'rgba(23, 43, 64, 0.15)',
                  borderRadius: 'var(--radius)',
                }}
              >
                <div className="flex items-center justify-between pb-2 border-b" style={{ borderColor: 'rgba(23, 43, 64, 0.1)' }}>
                  <div>
                    <h3 className="text-sm font-bold" style={{ color: 'var(--color-primary)' }}>
                      Edge Database: Committed Verification Records
                    </h3>
                    <p className="text-xs" style={{ color: 'var(--color-text)', opacity: 0.75 }}>
                      Only records satisfying all strict schema rules are committed to persistent storage.
                    </p>
                  </div>
                  <span 
                    className="text-xs px-2 py-0.5 font-bold uppercase text-white"
                    style={{
                      backgroundColor: 'var(--color-primary)',
                      borderRadius: 'var(--radius)',
                    }}
                  >
                    {records.length} Stored
                  </span>
                </div>

                {records.length === 0 ? (
                  <div className="py-8 text-center text-xs" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                    No verification records committed yet. Use the intake form to submit compliant records.
                  </div>
                ) : (
                  <div className="flex flex-col gap-3 overflow-y-auto max-h-[560px] pr-1">
                    {records.map((rec) => (
                      <div 
                        key={rec.id}
                        className="p-3 border text-xs leading-relaxed"
                        style={{
                          backgroundColor: 'var(--color-background)',
                          borderColor: 'rgba(23, 43, 64, 0.15)',
                          borderRadius: 'var(--radius)',
                        }}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="font-bold text-sm" style={{ color: 'var(--color-primary)' }}>
                            {rec.candidateName}
                          </span>
                          <span 
                            className="font-mono text-[10px] px-1.5 py-0.5 border bg-white"
                            style={{
                              borderColor: 'var(--color-primary)',
                              color: 'var(--color-primary)',
                              borderRadius: 'var(--radius)',
                            }}
                          >
                            {rec.id}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-x-2 gap-y-1 mb-2 text-[11px]">
                          <div>
                            <span className="font-semibold">Discipline: </span>
                            <span>{rec.degreeDiscipline}</span>
                          </div>
                          <div>
                            <span className="font-semibold">Graduation Year: </span>
                            <span>{rec.graduationYear}</span>
                          </div>
                          <div>
                            <span className="font-semibold">Work Auth: </span>
                            <span>{rec.workAuthorizationStatus}</span>
                          </div>
                          <div>
                            <span className="font-semibold">Status: </span>
                            <span className="font-bold" style={{ color: 'var(--color-primary)' }}>{rec.status}</span>
                          </div>
                        </div>

                        <div className="pt-2 border-t flex flex-col gap-1 text-[11px]" style={{ borderColor: 'rgba(23, 43, 64, 0.1)' }}>
                          <div className="flex items-center gap-1 truncate">
                            <span className="font-semibold flex-shrink-0">Artifact URL:</span>
                            <a 
                              href={rec.courseworkArtifactUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="underline truncate inline-flex items-center gap-0.5"
                              style={{ color: 'var(--color-primary)' }}
                            >
                              {rec.courseworkArtifactUrl}
                              <ExternalLink className="w-3 h-3 flex-shrink-0 inline" />
                            </a>
                          </div>
                          <div className="font-mono text-[10px] truncate" style={{ color: 'var(--color-text)', opacity: 0.7 }}>
                            Hash: {rec.recordHash}
                          </div>
                          <div className="text-[10px]" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                            Committed: {new Date(rec.timestamp).toLocaleString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tab 2: Immutable Audit Log */}
            {activeTab === 'audit' && (
              <div 
                className="p-4 border flex flex-col gap-3"
                style={{
                  backgroundColor: '#ffffff',
                  borderColor: 'rgba(23, 43, 64, 0.15)',
                  borderRadius: 'var(--radius)',
                }}
              >
                <div className="flex items-center justify-between pb-2 border-b" style={{ borderColor: 'rgba(23, 43, 64, 0.1)' }}>
                  <div>
                    <h3 className="text-sm font-bold" style={{ color: 'var(--color-primary)' }}>
                      Immutable Control Audit Log
                    </h3>
                    <p className="text-xs" style={{ color: 'var(--color-text)', opacity: 0.75 }}>
                      Captures all client halts, edge 400 rejections, and verified storage commits.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 absolute left-2 top-2" style={{ color: 'var(--color-text)', opacity: 0.5 }} />
                      <input
                        type="text"
                        placeholder="Filter audit logs..."
                        value={auditSearch}
                        onChange={(e) => setAuditSearch(e.target.value)}
                        className="pl-7 pr-2 py-1 text-xs border"
                        style={{
                          borderRadius: 'var(--radius)',
                          borderColor: 'rgba(23, 43, 64, 0.2)',
                        }}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-2 overflow-y-auto max-h-[560px] pr-1">
                  {filteredAuditLogs.length === 0 ? (
                    <div className="py-8 text-center text-xs" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                      No matching audit records found.
                    </div>
                  ) : (
                    filteredAuditLogs.map((entry) => (
                      <div
                        key={entry.id}
                        className="p-2.5 border text-xs"
                        style={{
                          backgroundColor: entry.outcome === 'SUCCESS' 
                            ? '#ffffff' 
                            : entry.outcome === 'HALTED' 
                              ? '#fffdfa' 
                              : '#fffbfb',
                          borderColor: entry.outcome === 'SUCCESS' 
                            ? 'rgba(23, 43, 64, 0.2)' 
                            : entry.outcome === 'HALTED' 
                              ? 'var(--color-focus)' 
                              : 'var(--color-error)',
                          borderRadius: 'var(--radius)',
                          borderLeftWidth: '4px',
                          borderLeftColor: entry.outcome === 'SUCCESS' 
                            ? 'var(--color-primary)' 
                            : entry.outcome === 'HALTED' 
                              ? 'var(--color-focus)' 
                              : 'var(--color-error)',
                        }}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-1.5">
                            {entry.outcome === 'SUCCESS' ? (
                              <CheckCircle2 className="w-3.5 h-3.5" style={{ color: 'var(--color-primary)' }} />
                            ) : entry.outcome === 'HALTED' ? (
                              <AlertTriangle className="w-3.5 h-3.5" style={{ color: 'var(--color-focus)' }} />
                            ) : (
                              <XCircle className="w-3.5 h-3.5" style={{ color: 'var(--color-error)' }} />
                            )}
                            <span className="font-bold text-[11px] font-mono">
                              {entry.action}
                            </span>
                          </div>
                          <span 
                            className="font-mono text-[10px] px-1 py-0.2 border bg-white"
                            style={{
                              borderRadius: 'var(--radius)',
                              borderColor: entry.outcome === 'SUCCESS' ? 'var(--color-primary)' : 'var(--color-error)',
                              color: entry.outcome === 'SUCCESS' ? 'var(--color-primary)' : 'var(--color-error)',
                            }}
                          >
                            HTTP {entry.httpStatus}
                          </span>
                        </div>

                        <div className="text-[11px] font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
                          {entry.reason}
                        </div>

                        <div className="text-[10px] font-mono text-slate-600 bg-white p-1.5 border rounded overflow-x-auto mb-1">
                          Payload: {JSON.stringify(entry.payloadSummary)}
                        </div>

                        <div className="flex items-center justify-between text-[10px]" style={{ color: 'var(--color-text)', opacity: 0.6 }}>
                          <span>Log ID: {entry.id}</span>
                          <span>{new Date(entry.timestamp).toLocaleTimeString()}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Audit & Compliance Specification Footer Notes */}
        <div 
          className="mt-6 p-4 border text-xs"
          style={{
            backgroundColor: '#ffffff',
            borderColor: 'rgba(23, 43, 64, 0.15)',
            borderRadius: 'var(--radius)',
          }}
        >
          <div className="font-bold mb-1" style={{ color: 'var(--color-primary)' }}>
            Compliance Lead Control Matrix (Feature F-02 Verification Checklist)
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-[11px] opacity-90 mt-2">
            <div className="p-2 border" style={{ borderRadius: 'var(--radius)', borderColor: 'rgba(23, 43, 64, 0.1)' }}>
              <div className="font-bold" style={{ color: 'var(--color-primary)' }}>1. Ubiquitous Schema</div>
              <div>Restricts payload attributes strictly to the 5 designated candidate attributes.</div>
            </div>
            <div className="p-2 border" style={{ borderRadius: 'var(--radius)', borderColor: 'rgba(23, 43, 64, 0.1)' }}>
              <div className="font-bold" style={{ color: 'var(--color-error)' }}>2. Edge 400 Rejection</div>
              <div>Missing, null, or empty fields trigger HTTP 400 with descriptive JSON error.</div>
            </div>
            <div className="p-2 border" style={{ borderRadius: 'var(--radius)', borderColor: 'rgba(23, 43, 64, 0.1)' }}>
              <div className="font-bold" style={{ color: 'var(--color-focus)' }}>3. State-driven textContent</div>
              <div>Active error rendered via textContent in #status-element while preserving form inputs.</div>
            </div>
            <div className="p-2 border" style={{ borderRadius: 'var(--radius)', borderColor: 'rgba(23, 43, 64, 0.1)' }}>
              <div className="font-bold" style={{ color: 'var(--color-primary)' }}>4. Unwanted-behavior Halt</div>
              <div>Any empty field blocks network dispatch and highlights inline warnings.</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
