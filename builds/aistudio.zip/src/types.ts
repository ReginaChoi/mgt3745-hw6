export interface CandidateVerificationPayload {
  candidateName: string;
  degreeDiscipline: string;
  graduationYear: number | string;
  workAuthorizationStatus: string;
  courseworkArtifactUrl: string;
}

export interface VerificationRecord {
  id: string;
  candidateName: string;
  degreeDiscipline: string;
  graduationYear: number;
  workAuthorizationStatus: string;
  courseworkArtifactUrl: string;
  timestamp: string;
  status: 'COMMITTED';
  recordHash: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: 'VERIFICATION_COMMITTED' | 'EDGE_REJECTED_400' | 'CLIENT_VALIDATION_HALTED' | 'EDGE_SCHEMA_VIOLATION';
  httpStatus: number | 'CLIENT_HALTED';
  payloadSummary: Record<string, unknown>;
  outcome: 'SUCCESS' | 'REJECTED' | 'HALTED';
  reason: string;
  validationErrors?: string[];
}

export const ALLOWED_ATTRIBUTES = [
  'candidateName',
  'degreeDiscipline',
  'graduationYear',
  'workAuthorizationStatus',
  'courseworkArtifactUrl',
] as const;

export type AllowedAttribute = (typeof ALLOWED_ATTRIBUTES)[number];
